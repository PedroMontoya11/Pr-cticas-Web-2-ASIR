<!DOCTYPE html>
<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale 1.0">
    <title>Inicio</title>
</head>
    <body>
        <h3><u><b><a href="Usuarios.php">Usuarios</a></b></u>&nbsp;&nbsp;&nbsp; <u><b><a href="Pisos.php">Pisos</a></b></u></h3>
    </body>
</html>