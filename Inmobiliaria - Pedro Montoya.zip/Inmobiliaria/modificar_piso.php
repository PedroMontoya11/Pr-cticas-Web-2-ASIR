<?php
$conexion = mysqli_connect("localhost", "root", "rootroot", "inmobiliaria")
    or die("No se ha podido realizar conexión con la base de datos");

if (isset($_POST["Enviar"])) 
{
    $codigo = $_POST["codigoPiso"];
    $nuevaCalle = $_POST["nuevaCalle"];
    $nuevoNum = $_POST["nuevoNum"];
    $nuevoPiso = $_POST["nuevoPiso"];
    $nuevaPuerta = $_POST["nuevaPuerta"];
    $nuevoCP = $_POST["nuevoCP"];
    $nuevosMetros = $_POST["nuevosMetros"];
    $nuevaZona = $_POST["nuevaZona"];
    $nuevoPrecio = $_POST["nuevoPrecio"];
    $nuevoUsuario = $_POST["nuevoUsuario"];

    $img = ""; 
    if (!empty($_FILES["imagen"]["name"])) 
    {
        $archivo_temporal = $_FILES["imagen"]["tmp_name"];
        $nombre_archivo = $_FILES["imagen"]["name"];

        $ruta = $nombre_archivo;
        move_uploaded_file($archivo_temporal, $ruta);

        $img = $ruta;
    }

    $consulta_usuario = "SELECT usuario_id FROM usuario WHERE nombres = '$nuevoUsuario'";
    $query_consulta_usuario = mysqli_query($conexion, $consulta_usuario);

    if ($query_consulta_usuario && mysqli_num_rows($query_consulta_usuario) == 1)
    {
        $fila_usuario = mysqli_fetch_assoc($query_consulta_usuario);
        $usuario_id = $fila_usuario["usuario_id"];

        if (empty($codigo) || empty($nuevaCalle) || empty($nuevoNum) || empty($nuevoPiso) || empty($nuevaPuerta) || empty($nuevoCP) || empty($nuevosMetros) || empty($nuevoPrecio) || empty($img))
        {
            echo '<script>alert("Rellene todos los campos");</script>';
        } 
        else
        {
            $consulta_piso = "SELECT * FROM pisos WHERE Codigo_piso = '$codigo'";
            $query_piso = mysqli_query($conexion, $consulta_piso);

            if ($query_piso && mysqli_num_rows($query_piso) == 1) 
            {
                $updatePiso = "UPDATE pisos SET calle = '$nuevaCalle', numero = '$nuevoNum', piso = '$nuevoPiso', puerta = '$nuevaPuerta', cp = '$nuevoCP', metros = '$nuevosMetros', zona = '$nuevaZona', precio = '$nuevoPrecio', imagen = '$img', usuario_id = $usuario_id WHERE Codigo_piso = '$codigo'";
                $query = mysqli_query($conexion, $updatePiso);

                if ($query) 
                {
                    echo '<script>alert("Piso actualizado correctamente");</script>';
                } 
                else 
                {
                    echo '<script>alert("Error al actualizar el piso");</script>';
                }
            }
            else 
            {
                echo '<script>alert("El piso no se encuentra registrado");</script>';
            }
        }
    } 
    else 
    {
        echo '<script>alert("Usuario no almacenado");</script>';
    }
}
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Modificar Piso</title>
    </head>
        <body>
        <form action="modificar_piso.php" method="post" enctype="multipart/form-data">
            <h3>Acualizar Piso</h3>
            Código de Piso: <input type="number" name="codigoPiso" min="1"><br><br>
            Calle: <input type="text" name="nuevaCalle" size="30"><br><br>
            Nº: <input type="number" min="1" name="nuevoNum" size="2"><br><br>
            Piso: <input type="number" min="1" name="nuevoPiso" size="2"><br><br>
            Puerta: <input type="text" name="nuevaPuerta"><br><br>
            Código Postal: <input type="number" min="1" name="nuevoCP" size="5"><br><br>
            Metros: <input type="number" min="1" name="nuevosMetros"><br><br>
            Zona: <input type="text" name="nuevaZona"><br><br>
            Precio: <input type="number" min="1" step="0.01" name="nuevoPrecio"><br><br>
            Imagen: <input type="file" name="imagen"><br>
            -------------------------------------------------<br><br>
            Nombre de Usuario: <input type="text" name="nuevoUsuario"><br><br>
            <input type="submit" name="Enviar" value="Actualizar piso"> <input type="reset" value="Limpiar"><br><br>
            <a href="index.php">Volver al Inicio</a>
        </form>
        </body>
</html>