<?php
$conexion = mysqli_connect("localhost", "root", "rootroot", "inmobiliaria")
or die("No se ha podido realizar conexión con la base de datos");

mysqli_select_db($conexion, "inmobiliaria") or die("Ninguna BBDD seleccionada");

if (isset($_POST["Eliminar"])) 
{
    $direccionEliminar = $_POST["dir_eliminar"];
    $numeroEliminar = $_POST["num_eliminar"];

    if (empty($direccionEliminar) || empty($numeroEliminar)) 
    {
        echo '<script>alert("Ingrese la dirección y el número del piso que desea eliminar");</script>';
    } 
    else 
    {
        
        $consultaListar = "SELECT Codigo_piso, calle, numero, piso, puerta, precio FROM pisos WHERE calle = '$direccionEliminar' AND numero = '$numeroEliminar'";
        $queryListar = mysqli_query($conexion, $consultaListar);

        if (mysqli_num_rows($queryListar) == 0) 
        {
            echo '<script>alert("No se encontraron pisos en la dirección y número proporcionado");</script>';
        } else 
        {
            echo "<form method='post' action=''>";
            echo "<label>Seleccione el piso a eliminar:</label>";
            echo "<select name='codigo_piso_eliminar'>";
            while ($row = mysqli_fetch_assoc($queryListar)) 
            {
                echo "<option value='" . $row['Codigo_piso'] . "'>" . $row['calle'] . " " . $row['numero'] . " - Piso " . $row['piso'] . " Puerta " . $row['puerta'] . " - Precio: " . $row['precio'] . "</option>";
            }
            echo "</select><br><br>";
            echo "<input type='submit' name='ConfirmarEliminar' value='Eliminar Piso'>";
            echo "</form>";
        }
    }
}

if (isset($_POST["ConfirmarEliminar"])) 
{
    $codigoPisoEliminar = $_POST["codigo_piso_eliminar"];

    $consultaEliminar = "DELETE FROM pisos WHERE Codigo_piso = '$codigoPisoEliminar'";
    $resultadoEliminar = mysqli_query($conexion, $consultaEliminar);

    if ($resultadoEliminar) 
    {
        echo '<script>alert("Piso eliminado correctamente");</script>';
    } 
    else 
    {
        echo '<script>alert("Error al intentar eliminar el piso");</script>';
    }
}
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Eliminar Piso</title>
</head>
    <body>
        <form action="borrar_piso.php" method="post">
            <h3>Eliminar Piso</h3>
            Dirección del piso: <input type="text" name="dir_eliminar"><br><br>
            Número del piso: <input type="number" name="num_eliminar" min="1"><br><br>
                <input type="submit" name="Eliminar" value="Siguiente"><br><br>
            <a href="index.php">Volver al Inicio</a>
        </form>
    </body>
</html>