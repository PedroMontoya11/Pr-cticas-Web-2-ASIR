<?php
$conexion = mysqli_connect("localhost", "root", "rootroot", "inmobiliaria")
or die ("No se ha podido realizar conexión con la base de datos");

mysqli_select_db($conexion, "inmobiliaria") or die ("Ninguna BBDD seleccionada");

if(isset($_POST["Buscar"]))
{
    $precio1 = $_POST["precio1"];
    $precio2 = $_POST["precio2"];

    if (empty($precio1) or (empty($precio2)))
    {
        echo '<script>alert("Ponga un precio mínimo y máximo");</script>';
    }
    else
    {
        $consultaBuscar = "SELECT * FROM pisos WHERE precio BETWEEN '$precio1' AND '$precio2' ORDER BY precio ASC";
        $query = mysqli_query($conexion, $consultaBuscar);

        if ($consultaBuscar && mysqli_num_rows($query) == 0)
        {
            echo '<script>alert("Ningún piso que cumpla los requisitos ha sido encontrado");</script>';
            echo "0 filas seleccionadas";
        }
        else
        {
            echo "<table border='1'>";
            echo "<tr><th>Código_Piso</th><th>Calle</th><th>Número</th><th>Piso</th><th>Puerta</th><th>Código Postal</th><th>Metros</th><th>Zona</th><th>Precio</th><th>Imagen</th><th>ID_Usuario</th></tr>";

            while ($row = mysqli_fetch_assoc($query)) 
            {
                echo "<tr>";
                echo "<td>" . $row['Codigo_piso'] . "</td>";
                echo "<td>" . $row['calle'] . "</td>";
                echo "<td>" . $row['numero'] . "</td>";
                echo "<td>" . $row['piso'] . "</td>";
                echo "<td>" . $row['puerta'] . "</td>";
                echo "<td>" . $row['cp'] . "</td>";
                echo "<td>" . $row['metros'] . "</td>";
                echo "<td>" . $row['zona'] . "</td>";
                echo "<td>" . $row['precio'] . "</td>";
                echo "<td>" . $row['imagen'] . "</td>";
                echo "<td>" . $row['usuario_id'] . "</td>";
                echo "</tr>";
            }
            echo "</table><br><br>";
        }
    }
}
mysqli_close($conexion);
?>