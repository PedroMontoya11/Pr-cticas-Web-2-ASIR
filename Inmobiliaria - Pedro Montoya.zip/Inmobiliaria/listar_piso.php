<?php
$conexion = mysqli_connect("localhost", "root", "rootroot", "inmobiliaria")
or die ("No se ha podido realizar conexión con la base de datos");

mysqli_select_db($conexion, "inmobiliaria") or die ("Ninguna BBDD seleccionada");

$query = "SELECT * FROM pisos";
$resultado = mysqli_query($conexion, $query);

if (!$resultado) 
{
    die("Error en la consulta: " . mysqli_error($conexion));
}
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Listar Pisos</title>
    </head>
        <body>
        <form action="listar_piso.php" method="post">
            <h3>Listar Pisos</h3>
        <?php
            echo "<table border='1'>";
            echo "<tr><th>Código_Piso</th><th>Calle</th><th>Número</th><th>Piso</th><th>Puerta</th><th>Código Postal</th><th>Metros</th><th>Zona</th><th>Precio</th><th>Imagen</th><th>ID_Usuario</th></tr>";

            while ($row = mysqli_fetch_assoc($resultado)) 
            {
                echo "<tr>";
                echo "<td>" . $row['Codigo_piso'] . "</td>";
                echo "<td>" . $row['calle'] . "</td>";
                echo "<td>" . $row['numero'] . "</td>";
                echo "<td>" . $row['piso'] . "</td>";
                echo "<td>" . $row['puerta'] . "</td>";
                echo "<td>" . $row['cp'] . "</td>";
                echo "<td>" . $row['metros'] . "</td>";
                echo "<td>" . $row['zona'] . "</td>";
                echo "<td>" . $row['precio'] . "</td>";
                echo "<td>" . $row['imagen'] . "</td>";
                echo "<td>" . $row['usuario_id'] . "</td>";
                echo "</tr>";
            }

            echo "</table><br><br>";
        mysqli_close($conexion);
        ?>
        
        <a href="index.php">Volver al Inicio</a>
        </form>
        </body>
</html>