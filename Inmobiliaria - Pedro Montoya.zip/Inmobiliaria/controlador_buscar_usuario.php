<?php
$conexion = mysqli_connect("localhost", "root", "rootroot", "inmobiliaria")
or die ("No se ha podido realizar conexión con la base de datos");

mysqli_select_db($conexion, "inmobiliaria") or die ("Ninguna BBDD seleccionada");

if(isset($_POST["Buscar"]))
{
    $userBuscar = $_POST["usuarioBuscar"];

    if (empty($userBuscar))
    {
        echo '<script>alert("Escriba un nombre de usuario a buscar");</script>';
    }
    else
    {
        $consultaBuscar = "SELECT * FROM usuario where nombres = '$userBuscar' ";
        $query = mysqli_query($conexion, $consultaBuscar);

        if ($consultaBuscar && mysqli_num_rows($query) == 0)
        {
            echo '<script>alert("El usuario no existe en la BBDD");</script>';
            echo "0 filas seleccionadas";
        }
        else
        {
            echo "<table border='1'>";
            echo "<tr><th>ID_Usuario</th><th>Nombre de Usuario</th><th>Correo Electrónico</th><th>Contraseña</th></tr>";

            while ($row = mysqli_fetch_assoc($query)) 
            {
                echo "<tr>";
                echo "<td>" . $row['usuario_id'] . "</td>";
                echo "<td>" . $row['nombres'] . "</td>";
                echo "<td>" . $row['correo'] . "</td>";
                echo "<td>" . $row['clave'] . "</td>";
                echo "</tr>";
            }
            echo "</table><br><br>";
        }
    }
}
mysqli_close($conexion);
?>