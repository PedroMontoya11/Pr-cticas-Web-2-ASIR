<!DOCTYPE html>
<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale 1.0">
    <title>Pisos</title>
</head>
    <body>
        <p>
            <a href="index.php"><u>Inicio</u></a> &nbsp;
            <a href="añadir_piso.php"><u>Añadir</u></a>&nbsp;
            <a href="listar_piso.php"><u>Listar</u></a>&nbsp;
            <a href="buscar_piso.php"><u>Buscar</u></a>&nbsp;
            <a href="modificar_piso.php"><u>Modificar</u></a>&nbsp;
            <a href="borrar_piso.php"><u>Borrar</u></a>&nbsp;
        </p>
    </body>
</html>