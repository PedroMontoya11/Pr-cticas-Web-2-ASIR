<?php
$conexion = mysqli_connect("localhost", "root", "rootroot", "inmobiliaria")
or die ("No se ha podido realizar conexión con la base de datos");

mysqli_select_db($conexion, "inmobiliaria") or die ("Ninguna BBDD seleccionada");

if(isset($_POST["Eliminar"]))
{
    $userDelete = $_POST["usuarioBorrar"];

    if (empty($userDelete))
    {
        echo '<script>alert("Por favor, rellene el campo de Usuario a borrar");</script>';
    }
    else
    {
        $consulta = "SELECT * FROM usuario where nombres = '$userDelete'";
        $consulta_Existencia = mysqli_query($conexion, $consulta);

        if ($consulta_Existencia && mysqli_num_rows($consulta_Existencia) == 0)
        {
            echo '<script>alert("Usuario no encontrado en la BBDD")</script>';
        }
        else
        {
            $deleteQuery = "DELETE FROM usuario where nombres = '$userDelete'";
            $resultadoQuery = mysqli_query($conexion, $deleteQuery);

            if ($resultadoQuery)
            {
                echo '<script>alert("Usuario eliminado correctamente")</script>';
            }
            else
            {
                echo '<script>alert("Error al borrar al usuario");</script>';
            }
        }
    }
}
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Borrar Usuario</title>
    </head>
        <body>
        <form action="borrar_usuario.php" method="post">
            <h3>Eliminar Usuario</h3>
            Usuario a borrar: <input type="text" name="usuarioBorrar"><br><br>
                <input type="submit" name="Eliminar" value="Borrar"><br><br>
            <a href="index.php">Volver al Inicio</a>
        </form>
        </body>
</html>