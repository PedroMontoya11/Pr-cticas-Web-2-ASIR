<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Buscar Usuario</title>
    </head>
        <body>
        <form action="controlador_buscar_usuario.php" method="post">
            <h3>Buscar Usuario</h3>
            Usuario a buscar: <input type="text" name="usuarioBuscar"><br><br>
                <input type="submit" name="Buscar" value="Buscar"> <input type="reset" value="Limpiar"><br><br>
            <a href="index.php">Volver al Inicio</a>
        </form>
        </body>
</html>