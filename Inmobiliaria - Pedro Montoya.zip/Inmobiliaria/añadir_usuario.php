<?php
$conexion = mysqli_connect("localhost", "root", "rootroot", "inmobiliaria")
or die ("No se ha podido realizar conexión con la base de datos");

mysqli_select_db($conexion, "inmobiliaria") or die ("Ninguna BBDD seleccionada");

if(isset($_POST["enviar"]))
{
    $user = $_POST["usuario"];
    $email = $_POST["correo"];
    $pass = $_POST["password"];

    if (empty($user) or (empty($email)) or (empty($pass)))
    {
        echo '<script>alert("Los campos no pueden estar vacíos");</script>';
    }
    else
    {
        $consulta = "SELECT * FROM usuario where nombres = '$user'";
        $consulta_Existencia = mysqli_query($conexion, $consulta);
        
        if ($consulta_Existencia && mysqli_num_rows($consulta_Existencia) >= 1)
        {
            echo '<script>alert("El usuario ya existe en la BBDD");</script>';
        }
        else
        {
            $insertQuery = "INSERT INTO usuario(nombres, correo, clave) VALUES ('$user', '$email', '$pass')";
            $resultadoQuery = mysqli_query($conexion, $insertQuery);

            if ($resultadoQuery)
            {
                echo '<script>alert("Usuario creado correctamente");</script>';
            }
            else
            {
                echo '<script>alert("Error al añadir al usuario");</script>';
            }
        }
    }
}
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Añadir Usuario</title>
    </head>
        <body>
        <form action="añadir_usuario.php" method="post">
            <h3>Insertar Usuarios</h3>
                Nombre de Usuario: <input type="text" name="usuario"><br><br>
                Correo electrónico: <input type="email" name="correo"><br><br>
                Contraseña: <input type="password" name="password"><br><br>
                    <input type="submit" name="enviar" value="Añadir"> <input type="reset" value="Limpiar"><br><br>
                <a href="index.php">Volver al Inicio</a>
        </form>
        </body>
</html>