<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Buscar Piso</title>
    </head>
        <body>
        <form action="controlador_buscar_piso.php" method="post">
            <h3>Buscar Piso</h3>
            Precio mínimo: <input type="number" name="precio1"><br><br>
            Precio máximo: <input type="number" name="precio2"><br><br>
                <input type="submit" name="Buscar" value="Buscar"> <input type="reset" value="Limpiar"><br><br>
            <a href="index.php">Volver al Inicio</a>
        </form>
        </body>
</html>