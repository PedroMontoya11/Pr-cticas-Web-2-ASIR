<?php
$conexion = mysqli_connect("localhost", "root", "rootroot", "inmobiliaria")
or die("No se ha podido realizar conexión con la base de datos");

if (isset($_POST["Enviar"])) 
{
    $username = $_POST["user"];
    $newUsername = $_POST["nuevoUser"];
    $newEmail = $_POST["nuevoCorreo"];
    $newPassword = $_POST["nuevaPassword"];

    if (empty($username)) 
    {
        echo '<script>alert("Escriba el nombre del usuario a modificar");</script>';
    } 
    else if (empty($newUsername) or (empty($newEmail)) or (empty($newPassword)))
    {
        echo '<script>alert("Rellene todos los datos a actualizar");</script>';
    }
    else
    {
        $ComprobarUser = "SELECT * FROM usuario WHERE nombres = '$username'";
        $resultadoQuery = mysqli_query($conexion, $ComprobarUser);

        if ($resultadoQuery && mysqli_num_rows($resultadoQuery) >= 1) 
        {
            $UpdateUser = "UPDATE usuario SET nombres = '$newUsername', correo = '$newEmail', clave = '$newPassword' WHERE nombres = '$username'";

            if (mysqli_query($conexion, $UpdateUser))
            {
                echo '<script>alert("Usuario actualizado correctamente");</script>';
            }
            else
            {
                echo '<script>alert("Error al actualizar el usuario: ' . mysqli_error($conexion) . '");</script>';
            }
        } 
        else 
        {
            echo '<script>alert("El usuario no existe en la base de datos");</script>';
        }
    }
}
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Modificar Usuario</title>
    </head>
        <body>
        <form action="modificar_usuario.php" method="post">
            <h3>Acualizar Usuario</h3>
            Nombre de usuario: <input type="text" name="user"><br><br>
            Nuevo nombre de usuario: <input type="text" name="nuevoUser"><br><br>
            Nuevo correo: <input type="email" name="nuevoCorreo"><br><br>
            Nueva contraseña: <input type="password" name="nuevaPassword"><br><br>
                <input type="submit" name="Enviar" value="Actualizar usuario"> <input type="reset" value="Limpiar"><br><br>
            <a href="index.php">Volver al Inicio</a>
        </form>
        </body>
</html>