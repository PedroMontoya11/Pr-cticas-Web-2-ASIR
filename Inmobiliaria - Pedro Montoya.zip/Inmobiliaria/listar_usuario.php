<?php
$conexion = mysqli_connect("localhost", "root", "rootroot", "inmobiliaria")
or die ("No se ha podido realizar conexión con la base de datos");

mysqli_select_db($conexion, "inmobiliaria") or die ("Ninguna BBDD seleccionada");

$query = "SELECT * FROM usuario";
$resultado = mysqli_query($conexion, $query);

if (!$resultado) 
{
    die("Error en la consulta: " . mysqli_error($conexion));
}
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Listar Usuarios</title>
    </head>
        <body>
        <form action="listar_usuario.php" method="post">
            <h3>Listar Usuarios</h3>
        <?php
            echo "<table border='1'>";
            echo "<tr><th>ID_Usuario</th><th>Nombre de Usuario</th><th>Correo Electrónico</th><th>Contraseña</th></tr>";

            while ($row = mysqli_fetch_assoc($resultado)) 
            {
                echo "<tr>";
                echo "<td>" . $row['usuario_id'] . "</td>";
                echo "<td>" . $row['nombres'] . "</td>";
                echo "<td>" . $row['correo'] . "</td>";
                echo "<td>" . $row['clave'] . "</td>";
                echo "</tr>";
            }

            echo "</table><br><br>";
        mysqli_close($conexion);
        ?>
        
        <a href="index.php">Volver al Inicio</a>
        </form>
        </body>
</html>