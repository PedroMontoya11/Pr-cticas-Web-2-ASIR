<?php
$conexion = mysqli_connect("localhost", "root", "rootroot", "inmobiliaria") or die("No se ha podido realizar conexión con la base de datos");
mysqli_select_db($conexion, "inmobiliaria") or die("Ninguna BBDD seleccionada");

if (isset($_POST["enviar"])) 
{
    $codigo = $_POST["codPiso"];
    $calle = $_POST["calle"];
    $numero = $_POST["numPiso"];
    $piso = $_POST["piso"];
    $puerta = $_POST["puerta"];
    $cp = $_POST["cp"];
    $metros = $_POST["metros"];
    $zona = $_POST["zona"];
    $precio = $_POST["precio"];

    
    $img = ""; 
    if (!empty($_FILES["imagen"]["name"])) 
    {
        $archivo_temporal = $_FILES["imagen"]["tmp_name"];
        $nombre_archivo = $_FILES["imagen"]["name"];

        $ruta = $nombre_archivo;
        move_uploaded_file($archivo_temporal, $ruta);

        $img = $ruta;
    }

    $nombre_usuario = $_POST["nombreUsuario"];

    
    $consulta_usuario = "SELECT usuario_id FROM usuario WHERE nombres = '$nombre_usuario'";
    $query_usuario = mysqli_query($conexion, $consulta_usuario);

    if ($query_usuario && mysqli_num_rows($query_usuario) == 1) 
    {
        $fila_usuario = mysqli_fetch_assoc($query_usuario);
        $usuario_id = $fila_usuario["usuario_id"];

       
        if (empty($codigo) || empty($calle) || empty($numero) || empty($piso) || empty($puerta) || empty($cp) || empty($metros) || empty($precio) || empty($img)) 
        {
            echo '<script>alert("Rellene todos los campos");</script>';
        }
        else 
        {
            $consulta_piso = "SELECT * FROM pisos WHERE Codigo_piso = '$codigo'";
            $query_piso = mysqli_query($conexion, $consulta_piso);

            if ($query_piso && mysqli_num_rows($query_piso) == 1) 
            {
                echo '<script>alert("El piso ya se encuentra registrado");</script>';
            } else 
            {
                $insertPisoQuery = "INSERT INTO pisos(Codigo_piso, calle, numero, piso, puerta, cp, metros, zona, precio, imagen, usuario_id) VALUES ('$codigo', '$calle', '$numero', '$piso', '$puerta', '$cp', '$metros', '$zona', '$precio', '$img', '$usuario_id')";
                $resultado = mysqli_query($conexion, $insertPisoQuery);

                if ($resultado) 
                {
                    echo '<script>alert("Piso añadido correctamente");</script>';
                } else 
                {
                    echo '<script>alert("Error al añadir el piso");</script>';
                }
            }
        }
    } 
    else 
    {
        echo '<script>alert("Usuario no almacenado");</script>';
    }
}
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Añadir Piso</title>
</head>

    <body>
        <form action="añadir_piso.php" method="post" enctype="multipart/form-data">
            <h3>Insertar Piso</h3>
            Código de Piso: <input type="number" min="1" name="codPiso"><br><br>
            Calle: <input type="text" name="calle" size="30"><br><br>
            Nº: <input type="number" min="1" name="numPiso" size="2"><br><br>
            Piso: <input type="number" min="1" name="piso" size="2"><br><br>
            Puerta: <input type="text" name="puerta"><br><br>
            Código Postal: <input type="number" min="1" name="cp" size="5"><br><br>
            Metros: <input type="number" min="1" name="metros"><br><br>
            Zona: <input type="text" name="zona"><br><br>
            Precio: <input type="number" min="1" step="0.01" name="precio"><br><br>
            Imagen: <input type="file" name="imagen"><br>
            -------------------------------------------------<br><br>
            Nombre de Usuario: <input type="text" name="nombreUsuario"><br><br>
            <input type="submit" name="enviar" value="Añadir"> <input type="reset" value="Limpiar"><br><br>
            <a href="index.php">Volver al Inicio</a>
        </form>
    </body>
</html>