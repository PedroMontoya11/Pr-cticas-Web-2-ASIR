<!DOCTYPE html>
<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale 1.0">
    <title>Usuarios</title>
</head>
    <body>
        <p>
            <a href="index.php"><u>Inicio</u></a> &nbsp;
            <a href="añadir_usuario.php"><u>Añadir</u></a>&nbsp;
            <a href="listar_usuario.php"><u>Listar</u></a>&nbsp;
            <a href="buscar_usuario.php"><u>Buscar</u></a>&nbsp;
            <a href="modificar_usuario.php"><u>Modificar</u></a>&nbsp;
            <a href="borrar_usuario.php"><u>Borrar</u></a>&nbsp;
        </p>
    </body>
</html>