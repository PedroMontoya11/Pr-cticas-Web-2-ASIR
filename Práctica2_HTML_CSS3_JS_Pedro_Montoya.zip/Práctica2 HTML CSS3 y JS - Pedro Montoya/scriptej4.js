let form1 = document.getElementById("form1");
let nombre = document.getElementById("nombre");
let apellido1 = document.getElementById("apellido1");
let apellido2 = document.getElementById("apellido2");
let correo = document.getElementById("correo");
let provincia = document.getElementById("provincia");
let numss1 = document.getElementById("numss1");
let numss2 = document.getElementById("numss2");


let enviarBoton = document.getElementById("enviar");
let borrarBoton = document.getElementById("borrar");


enviarBoton.addEventListener("click", function() 
{
    if (validar())
    {
        form1.submit(); //
    }
});

borrarBoton.addEventListener("click", function() 
{
    form1.reset();
});

function validar() 
{
    if (nombre.value == "") 
    {
        nombre.focus();
            alert("El campo nombre no puede estar vacío");
        return false;
    }
    if (apellido1.value == "") 
    {
        apellido1.focus();
            alert("El campo del primer apellido no puede estar vacío");
        return false;
    }
    if (apellido2.value == "") 
    {
        apellido2.focus();
            alert("El campo del segundo apellido no puede estar vacío");
        return false;
    }
    if (correo.value == "") 
    {
        correo.focus();
            alert("El campo de correo no puede estar vacío");
        return false;
    }   else 
    {
        let email = correo.value;
        let pos = email.indexOf("@");
        let pos1 = email.indexOf(".");
            if (pos == -1 || pos1 == -1) 
            {
                correo.focus();
                    alert("El correo debe tener un formato válido");
                return false;
            }
            if(pos1<pos)
            {
                correo.focus();            
                    alert("El . no puede ir antes del @");
                return false;
            }
    }
    if (provincia.value == "")
    {
        provincia.focus();
            alert("Seleccione una provincia");
        return false;
    }
    if (numss1.value == "")
    {
        numss1.focus();
            alert("Rellene el campo del primer número");
        return false;
    }
    if (isNaN (numss1.value))
    {
        numss1.focus();
            alert("Sólo se permiten números");
        return false;
    } 
    else if (numss1.value.length != 7) 
    {
        numss1.focus();
            alert("Debe ser un número de 7 dígitos");
        return false;
    }
    if (numss2.value == "")
    {
        numss2.focus();
            alert("Rellene el campo del segundo número");
        return false;
    }
    if (isNaN (numss2.value))
    {
        numss2.focus();
            alert("Sólo se permiten números");
        return false;
    } 
    else if (numss2.value.length > 2)
    {
        numss2.focus();
            alert("Debe ser un número de 1 o 2 dígitos");
        return false;
    }
    alert ("Datos correctos");
}