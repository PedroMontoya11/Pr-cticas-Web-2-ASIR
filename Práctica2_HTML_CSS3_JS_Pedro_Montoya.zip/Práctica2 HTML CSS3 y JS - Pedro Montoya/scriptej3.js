function calcularNota()
{
    let pregunta1 = document.getElementById("pregunta1");
    let opcion1a = document.form1.p1[0].checked;
    let opcion1b = document.form1.p1[1].checked;
    let opcion1c = document.form1.p1[2].checked;
    let opcion1d = document.form1.p1[3].checked;
    let pregunta2 = document.getElementById("pregunta2");
    let opcion2a = document.form1.p2[0].checked;
    let opcion2b = document.form1.p2[1].checked;
    let opcion2c = document.form1.p2[2].checked;
    let opcion2d = document.form1.p2[3].checked;
    let pregunta3 = document.getElementById("pregunta3");
    let opcion3a = document.form1.p3[0].checked;
    let opcion3b = document.form1.p3[1].checked;
    let opcion3c = document.form1.p3[2].checked;
    let opcion3d = document.form1.p3[3].checked;
    let pregunta4 = document.getElementById("pregunta4");
    let opcion4a = document.form1.p4[0].checked;
    let opcion4b = document.form1.p4[1].checked;
    let opcion4c = document.form1.p4[2].checked;
    let opcion4d = document.form1.p4[3].checked;
    let pregunta5 = document.getElementById("pregunta5");
    let opcion5a = document.form1.p5[0].checked;
    let opcion5b = document.form1.p5[1].checked;
    let opcion5c = document.form1.p5[2].checked;
    let opcion5d = document.form1.p5[3].checked;
        let aciertos = 0;
        let numpreg = 5;
    if (opcion1c==true)
    {
        aciertos += 1;
        
    }
    if (opcion2b==true)
    {
        aciertos += 1;   
    }
    if (opcion3d==true)
    {
        aciertos += 1;
    }
    if (opcion4d==true)
    {
        aciertos += 1;
    }
    if (opcion5a==true)
    {
        aciertos += 1;
    }
    var nota = parseFloat((aciertos / numpreg) * 10);
    alert("Nota final: " +nota);
}