function cambiarColorFondo()
{
    let div1 = document.getElementById("div1");
    div1.style.backgroundColor = getRandomColor();
}

function cambiarTexto() 
{
    let div1 = document.getElementById("div1");
    let nuevoTexto = prompt("Introduzca texto");
    div1.textContent = nuevoTexto;
}

function cambiarTipoYColorDeLetra() 
{
    let div1 = document.getElementById("div1");
    let nuevoTipoDeLetra = prompt("Introduzca el tipo de letra");
    let nuevoColorDeLetra = prompt("Introduce el color de letra");
    div1.style.fontFamily = nuevoTipoDeLetra;
    div1.style.color = nuevoColorDeLetra;
}

function getRandomColor() 
{
    let letras = "0123456789ABCDEF";
    let color = "#";
    for (let i = 0; i < 6; i++) 
    {
        color += letras[Math.floor(Math.random() * 16)];
    }
    return color;
}