<?php
$fichero = "agenda.txt";
if (isset($_REQUEST["Guardar"])) 
{
    $nombre = trim(strip_tags($_REQUEST["nombre"] ?? ""));
    $trabajo = trim(strip_tags($_REQUEST["trabajo"] ?? ""));
    $tlf = trim(strip_tags($_REQUEST["telefono"] ?? ""));
    $direccion = trim(strip_tags($_REQUEST["direccion"] ?? ""));
    $otras = trim(strip_tags($_REQUEST["otras"] ?? ""));

    if (empty($nombre))
    {
        echo "<p>Rellene el campo de nombre</p>";

    }
    elseif (strlen($nombre) < 2)
    {
        echo "<p>Mínimo 2 caracteres en el campo de nombre</p>";
    } 
    elseif (empty($trabajo)) 
    {
        echo "<p>Rellene el campo de trabajo</p>";
    } 
    elseif (empty($tlf))
    {
        echo "<p>Rellene el campo de teléfono</p>";
    }
    elseif (empty($direccion))
    {
        echo "<p>Rellene el campo de dirección</p>";
    }
    elseif (!is_numeric($tlf))
    {
        echo "<p>Solo se permiten números en el teléfono</p>";
    }
    elseif (strlen($tlf) < 9)
    {
        echo "<p>Mínimo 9 caracteres en el campo de teléfono</p>";
    } else 
        {
            $archivo = fopen($fichero, "a");
            fwrite($archivo, "Contacto: $nombre $trabajo $tlf $direccion $otras" . PHP_EOL);
            fclose($archivo);
            echo "Datos escritos en el archivo agenda.txt";
        }
}
elseif (isset($_REQUEST["Mostrar"]))
{
    $contenido = file_get_contents($fichero);
    echo "<pre>$contenido</pre>";
}
elseif (isset($_REQUEST["Buscar"]))
{
    $Buscar = trim(strip_tags($_REQUEST["Buscar_contacto"]));
    $file = fopen($fichero, "r");
    $encontrado = false;
    if (empty($Buscar))
    {
        echo "<p>Escriba un nombre a buscar</p>";
    }
    elseif (strlen($Buscar) < 2)
    {
        echo "<p>Mínimo 2 caracteres</p>";
    } 
    else
    {
        while(!feof($file))
        {
            $linea = fgets($file);
        
            if (strpos($linea, "Contacto: $Buscar") !== false)
            {
                echo "El contacto $Buscar se encuentra agendado<br>";
                echo $linea;
                $encontrado = true;
            }
        }
        fclose($file);
        if (!$encontrado)
        {
            echo "El contacto $Buscar no se encuentra agendado";
        }
    }       
}
?>