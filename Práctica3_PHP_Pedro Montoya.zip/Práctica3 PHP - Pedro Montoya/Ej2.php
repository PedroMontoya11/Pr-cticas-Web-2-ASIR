<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Ejercicio2</title>
</head>
        <body>
            <?php
            print "<h2>Jugador 1</h2>";
            $countjug1 = 0;
                for ($i = 0; $i<6; $i++)
                {
                    $dadojug1 = rand(1,6);
                        print "<img src= ../img/$dadojug1.jpg>\n";
                    $countjug1 = $countjug1 + $dadojug1;
                }
                print "<h2>Resultado Jugador 1: $countjug1</h2>";

                print "<h2>Jugador 2</h2>";
                $countjug2 = 0;
                for ($i = 0; $i<6; $i++)
                {
                    $dadojug2 = rand(1,6);
                        print "<img src= ../img/$dadojug2.jpg>\n";
                    $countjug2 = $countjug2 + $dadojug2;
                }
                print "<h2>Resultado Jugador 2: $countjug2</h2>";

                if ($countjug1 > $countjug2)
                {
                    print "<p>En conjunto, ha ganado el jugador <b>1</b></p>";
                }
                elseif ($countjug2 > $countjug1)
                {
                    print "<p>En conjunto, ha ganado el jugador <b>2</b></p>";
                }
                else
                {
                    print "Hay un empate";
                }
            ?>
        </body>
</html>