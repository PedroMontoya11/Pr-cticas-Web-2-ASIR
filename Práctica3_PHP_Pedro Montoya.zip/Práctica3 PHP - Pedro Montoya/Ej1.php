<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Ejercicio1</title>
    <style>
    #leyenda
    {
        background-color: white;
        border: 3px solid #9090ff;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 90%;
        font-weight: bold;
    }
    #campo
    {
        background-color: #e6e6ff;
        border: 3px solid #9090ff;
    }
    #altotxt
    {
        margin-left: 0.06em;
    }
    #alto
    {
        margin-left: 1.1em;
    }
    </style>
</head>
<body>
    <form action="ejercicio1.php" method="get">
        <fieldset id="campo">
            <legend id="leyenda">Formulario</legend>
            <p>Escriba el alto y ancho (0 < números ≤ 100) y mostraré un rectángulo de estrellas de ese tamaño.</p>
                <p><b>Ancho: </b><input type="text" name="ancho" size="1"></p>
                <p id="altotxt"><b> Alto: </b><input type="text" name="alto" id="alto" size="1"></p>
                <p><input type="submit" value="Dibujar"> <input type="reset" value="Borrar"></p>
        </fieldset>
    </form>
</body>
</html>