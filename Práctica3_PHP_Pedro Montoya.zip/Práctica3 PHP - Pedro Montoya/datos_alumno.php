<?php
$nombre = trim(strip_tags($_REQUEST["nombre"] ?? ""));
$telefono = trim(strip_tags($_REQUEST["tlf"] ?? ""));
$matr = isset($_REQUEST["matriculado"]) ? "matriculado" : "no matriculado";
$estudios = isset($_REQUEST["estudios"]) ? $_REQUEST["estudios"] : "";
$mostrar = $_REQUEST["datos"] ?? "";
if (empty($nombre))
{
    echo "Rellene el campo de nombre";
}
    elseif (strlen($nombre)<2)
    {
        echo "Mínimo 2 caracteres en el campo de nombre";
    }
    elseif (empty($telefono)) 
    {
        echo "Rellene el campo de teléfono";
    }
    elseif (!is_numeric($telefono))
    {
        echo "Solo se permiten números en el teléfono";
    }
    elseif (strlen($telefono)<9)
    {
        echo "Mínimo 9 caracteres en el campo de teléfono";
    }
    elseif (empty($estudios))
    {
        echo "Especifique el nivel de enseñanza";
    } 
else
{
    if ($mostrar == "Por Pantalla")
    {
        echo "El alumno <b>$nombre</b>, con teléfono <b>$telefono</b>, está <b>$matr</b> en <b>$estudios</b>";
    }
    elseif ($mostrar == "En Archivo datos.txt")
    {
        $fichero = "datos.txt";
        $mensaje = "El alumno $nombre, con teléfono $telefono, está $matr en $estudios". PHP_EOL;
        $fd = fopen($fichero, "a");
        fwrite($fd, $mensaje);
        fclose($fd);
                echo "Datos escritos en el archivo datos.txt";
    } else
        {
            echo "Error al abrir el archivo datos.txt para escritura";
        } 
}
?>