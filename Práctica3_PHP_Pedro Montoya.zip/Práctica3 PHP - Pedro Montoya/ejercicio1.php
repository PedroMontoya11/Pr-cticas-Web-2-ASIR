<?php
    $ancho = $_REQUEST["ancho"];
    $alto = $_REQUEST["alto"];
    if (is_numeric($ancho) && (is_numeric($alto)))
    {
        if ($ancho <= 0 || $alto <= 0)
        {
            echo "Tiene que escribir un número mayor de 0\n";
        }
        elseif ($ancho > 100 || $alto > 100)
        {
            echo "Tiene que escribir un número menor o igual a 100\n";
        }
        else
        {
            echo "Alto: ". $alto. "<br>";
            echo "Ancho: ". $ancho. "<br><br>";
            for ($j = 1; $j <= $alto; $j++)
            {
                for ($i = 1; $i <= $ancho; $i++)
                {
                    print "*\n";
                }
                echo "<br>";
            }
        }
    }
    else
    {
        echo "Tiene que añadir números en ambos campos";
    }
?>